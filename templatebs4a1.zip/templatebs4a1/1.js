﻿ var app = angular.module('myApp',['ngMaterial']);
 app.controller('MyController',  function($scope){
  
 })